function sendResetEmail() {
    const email = document.getElementById('email').value;
    const message = document.getElementById('message');

  
    if (email) {
        message.textContent = `Password reset email sent to ${email}`;
    } else {
        message.textContent = 'Please enter a valid email address.';
    }
}





//...........node js...............

const express = require('express');
const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Replace these with your actual email service credentials
const emailUser = 'your_email@gmail.com';
const emailPass = 'your_email_password';

app.post('/forgot-password', (req, res) => {
    const email = req.body.email;
    
    // You would typically generate a unique token here and save it to a database
    // for password reset verification. For simplicity, we're not doing that here.
    
    const resetLink = 'https://yourwebsite.com/reset-password?token=unique_token';

    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: emailUser,
            pass: emailPass,
        },
    });

    const mailOptions = {
        from: emailUser,
        to: email,
        subject: 'Password Reset',
        text: `To reset your password, click the following link: ${resetLink}`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error(error);
            res.status(500).json({ message: 'Email could not be sent' });
        } else {
            console.log('Email sent: ' + info.response);
            res.json({ message: 'Password reset email sent successfully' });
        }
    });
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});